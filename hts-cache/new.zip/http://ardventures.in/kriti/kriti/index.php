<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Kriti</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor - v2.1.0
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body style="color:#5299e6;font-style:normal;">

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top" style="background:white; color:#094c84;">
    <div class="container d-flex align-items-center">

      
	  <a href="index.php"><img src="assets/img/122.png" style="height:100px;"></a>
	  
	 
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
         
          
		  
		   <li class="drop-down"><a style=" color:#5299e6;" href="">DEMO SESSION</a>
            <ul>
              <li><a href="demo12.php" style=" color:#5299e6;">Class 12</a></li>
              <li><a href="demo11.php" style=" color:#5299e6;">Class 11</a></li>
              <li><a href="demo10.php" style=" color:#5299e6;">Class 10</a></li>
              <li><a href="demo9.php" style=" color:#5299e6;">Class 9</a></li>
            </ul>
          </li>
		  <li class="drop-down"><a style=" color:#5299e6;" href="">KNOWLEDGE BITES</a>
            <ul>
              <li><a href="currentaff.php" style=" color:#5299e6;">Current Affairs</a></li>
              <li><a href="careercon.php" style=" color:#5299e6;"> Career Counselling</a></li>
              <li><a href="persanility.php" style=" color:#5299e6;">Personality Development</a></li>
              <li><a href="intervie.php" style=" color:#5299e6;">Interview Skills</a></li>
              <li><a href="powerpake.php" style=" color:#5299e6;">Power Packed Sessions</a></li>
              <li><a href="success.php" style=" color:#5299e6;">Success Mantra</a></li>
            </ul>
          </li>
		 

		     
          
         <li class="drop-down"><a style=" color:#5299e6;" href=""> STUDY MATERIAL</a>
            <ul>
              <li><a href="Pryear.php" style=" color:#5299e6;">Previous Year Paper</a></li>
              <li><a href="samplepaper.php" style=" color:#5299e6;"> Sample Papers</a></li>
              <li><a href="mock_paper.php" style=" color:#5299e6;">Social – Mock Papers
</a></li>
            <li><a href="course-details2.php" style=" color:#5299e6;">Social – NCERT Books

</a></li>   

<li><a href="course-details2.php" style=" color:#5299e6;">Toppers Answers Sheets


</a></li> 

<li><a href="course-details2.php" style=" color:#5299e6;">Important Questions


</a></li>



            </ul>
          </li>
         
           <li class="drop-down"><a style=" color:#5299e6;" href=""> SUBJECTS OFFERES</a>
            <ul>
              <li><a href="course-details.php" style=" color:#5299e6;">Commerce (XI – XII)</a></li>
              <li><a href="course-details1.php" style=" color:#5299e6;"> Humanities (XI – XII)</a></li>
              <li><a href="course-details2.php" style=" color:#5299e6;">Social – Science (IX – X)</a></li>
              
            </ul>
          </li>
          
        <li class="drop-down"><a style=" color:#5299e6;" href="courses.php"> GET ONLINE</a>
            <ul>
              <li><a href="http://ardventures.in/Coaching/coacing/sms/student/" style=" color:#5299e6;">For Student</a></li>
              <li><a href="http://ardventures.in/Coaching/coacing/sms/teacher/" style=" color:#5299e6;"> For Teacher</a></li>
              
            </ul>
          </li>

        </ul>
      </nav><!-- .nav-menu -->

      <a href="courses.php" class="get-started-btn" style="border:2px solid silver;background:#5299e6; color:white;" >
	  ENROLL NOW</a>

    </div>
  </header>
 <!-- End Header -->
<br/>
<br/>
<br/>
<br/>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-content-center align-items-center">
    <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
</head>
<body>

<video style="width: 100%;" autoplay muted loop id="myVideo">
  <source src="bbb.mp4" type="video/mp4">
 
</video>





</body>
</html>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" style="color:blue;background-color:orange" data-aos="fade-up">

        <div class="section-title" style="color:blue;background-color:orange">
        
          <p style="color:white;">नई परंपराओं का भारत +</p>
        </div>

        <div class="row" style="background:white;color:green;">
          <div class="col-sm-8" data-aos="fade-left" data-aos-delay="100">
            <br/>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/8Dn0JszlmKo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
		  
          <div class="col-sm-4 content">
           
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.accordion:after {
  content: '\002B';
  color: #777;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2212";
}

.panel {
  padding: 0 18px;
  background-color: white;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}
</style>
</head>
<body>
<div class="row" >
<h3></h3><br/>
</div>
<div class="row">
<p style="text-align:justify;color:#5299e6;">Welcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore the real you.
The world is transforming and so as are we. In today’s world where various aspects of personality are
core for a defined and settled career then why learning for it should be time bounded. </p>
 <br/>
 <br/> 
 <a href="courses.php" style="border-radius:0px;background:#5299e6;color:white;border:3px solid silver;padding:7px 7px 7px 7px; font-size:15px;" class="btn-get-started">
	 Click For More Information </a>
 
</div>

</body>
</html>
          </div>
		  
        </div>

      </div>
    </section>
	
	
	
	
	
	<section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
         
         
        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/wew.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
          <h2>Explore The Real You</h2>
		  <br/>
		  <br/>
          <p style="color:#ffbb2c;text-align:justify;">Welcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded. elcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded. elcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded.

</p>
          </div>
        </div>

      </div>
    </section>
	
	
	<section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
         
         
        </div>

        <div class="row">
         <div class="col-lg-6">
            <img src="assets/img/waaa.jpg" class="img-fluid" alt="">
          </div>
		  
		  
 <div class="col-lg-6">
          <h2>Digital Catalogue </h2>
		  <br/>
		  <br/>
          <p style="color:#ffbb2c;text-align:justify;">Welcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded. elcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded. elcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded.

</p>
          </div>
		 
         
        </div>

      </div>
    </section>
	
	
	
	<section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
         
         
        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/cdd.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
          <h2>Conferring  Sessions</h2>
		  <br/>
		  <br/>
          <p style="color:#ffbb2c;text-align:justify;">Welcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded. elcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded. elcome to the Web Platform of Narendra’s – Kirti Study Center, a digital way to explore 
		  the real you. The world is transforming and so as are we. In today’s world where various aspects of personality are
		  core for a defined and settled career then why learning for it should be time bounded.

</p>
          </div>
        </div>

      </div>
    </section>
	
	
	<section id="features" class="features">
      <div class="container" data-aos="fade-up">
<div class="section-title">
      
          <p style="color:#5299e6;;">Package We Offer</p>
        </div>
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-3 col-md-4">
            <div class="icon-box">
              <i class="ri-store-line" style="color: #ffbb2c;"></i>
              <h6><a href="" style="color:#ffbb2c; font-size:15px;">Structured Pack </a></h6>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="ri-bar-chart-box-line" style="color: #5578ff;"></i>
              <h6><a href="" style="color:#5578ff; font-size:15px;">Contrived Pack</a></h6>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="ri-calendar-todo-line" style="color: #e80368;"></i>
              <h6><a href="" style="color:#e80368; font-size:15px;">Solitary Pack </a></h6>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4 mt-lg-0">
            <div class="icon-box">
              <i class="ri-paint-brush-line" style="color: #e361ff;"></i>
              <h6><a href="" style="color:#e464ff; font-size:15px;">Induction Pack </a></h6>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box">
              <i class="ri-database-2-line" style="color: #47aeff;"></i>
              <h6><a href="" style="color:#47aeff; font-size:15px;">Recasting Pack </a></h6>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box">
              <i class="ri-gradienter-line" style="color: #ffa76e;"></i>
              <h6><a href="" style="color:#ffa870; font-size:13px;">Assessment Pack</a></h6>
            </div>
          </div>
          
          

      </div>
    </section>
	
	
	
	<section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2></h2>
          <p style="color:#5299e6;">The Ideology of Narendra’s Kirti Study Centre</p>
        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/re.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
           
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.accordion:after {
  content: '\002B';
  color: #777;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2212";
}

.panel {
  padding: 0 18px;
  background-color: white;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}
</style>
</head>
<body>

<h2>About US</h2><br/>
<p style="text-align:justify;">Narendra’s – Kirti Study Centre is a platform where we are destined to build such a platform
at which the child is led on a path which is fearless and truthful. Here we guide them to express,
to recreate themselves and fly into the world where they see themselves as a person satisfying
his/her dreams into reality.</p>
<p style="text-align:justify;">We, at Narendra’s – Kirti Study Centre, understand that the Percentage Based Result affect
many things in your career and somewhere helps in fetching a handsome salary at initial level
but that alone is not the defining criteria for anyone’s future. We believe in children and their
endeavours, we believe in their faith on themselves and this belief on them act as a torch-light
in their dark paths. We do not lead them, we help them, we care for them and we value their
emotions. By taking the help of our experience we help them in doing smart</p>
 


<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
</script>

</body>
</html>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->



	
	
	
	
	
	
    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts section-bg">
      <div class="container">

        <div class="row counters">

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up" style="color:#5299e6;">1232</span>
            <p style="color:#5299e6;">Students</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up"style="color:#5299e6;">64</span>
            <p style="color:#5299e6;">Courses</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up"style="color:#5299e6;">42</span>
            <p style="color:#5299e6;">Events</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up" style="color:#5299e6;">15</span>
            <p style="color:#5299e6;">Trainers</p>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Why Us Section ======= -->
    <!-- End Why Us Section -->







    <!-- ======= Features Section ======= -->
    <!-- End Features Section -->



	
	
    <!-- ======= Popular Courses Section ======= -->
    <!-- End Popular Courses Section -->

    <!-- ======= Trainers Section ======= -->
    <section id="trainers" class="trainers">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2 style="color:#5299e6;;">Teacher</h2>
          <p style="color:#5299e6;;">Our Professional Teacher</p>
        </div>

        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
           <div class="member">
              <img src="assets/img/kriti.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4> 
Kirti Saxena 			
</h4>
                <span>Academic Head & Director</span>
                
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/Smt. Neeru Saxena  - Chairperson .jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4> Neeru Saxena  
</h4>
                <span>Chairperson</span>
               
              
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
           <div class="member">
              <img src="assets/img/trainers/trainer-2.jpg" class="img-fluid" alt="">
         
			 <div class="member-content">
                <h4>Smt. Neeru Saxena  
</h4>
                <span>Chairperson</span>
                
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Trainers Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" style=" color:#5299e6;">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact" style=" color:#5299e6;">
            <h6 style=" color:#5299e6;">Narendra Kriti Study Center</h6>
            <p style=" color:#5299e6;">
              2, Alka Puri, <br>
              Near Bersheba Church,<br>
              Udayan Marg, Ujjain – 456010 <br>
             Madhya Pradesh <br><br>
			  
			 



              <strong>Phone:</strong> +91 7987893235<br>
              <strong>Email:</strong> kirtistudycenter@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4 style=" color:#5299e6;">Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a style="    font-size: 16px; color:#5299e6;" href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a style="    font-size: 16px; color:#5299e6;" href="about.php">About us</a></li>
             
              <li><i class="bx bx-chevron-right"></i> <a style="font-size: 16px; color:#5299e6;" href="term.php">Our Administrative Team</a></li>
              
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4 style=" color:#5299e6;">Our Services</h4>
            <ul>
              <li><a href="course-details.php" style="font-size:16px; color:#5299e6;">Commerce (XI – XII)</a></li>
              <li><a href="course-details1.php" style="font-size:16px; color:#5299e6;"> Humanities (XI – XII)</a></li>
              <li><a href="course-details2.php" style="font-size:16px; color:#5299e6;">Social – Science (IX – X)</a></li>
              
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 style=" color:#5299e6;">Join Our Newsletter</h4>
            <p style=" color:#5299e6;"></p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" style="background:#5299e6;"value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>TSI</span></strong>
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/ -->
          
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" style="background:#5299e6;"class="twitter" ><i  class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"style="background:#5299e6;"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"style="background:#5299e6;"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="instagram"style="background:#5299e6;"><i class="bx bxl-youtube"></i></a>
     
       
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>

</html>