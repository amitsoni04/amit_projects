<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>About</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor - v2.1.0
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top" style="background:white; color:#094c84;">
    <div class="container d-flex align-items-center">

      
	  <a href="index.php"><img src="assets/img/122.png" style="height:100px;"></a>
	  
	 
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
         
          
		  
		   <li class="drop-down"><a style=" color:#5299e6;" href="">DEMO SESSION</a>
            <ul>
              <li><a href="demo12.php" style=" color:#5299e6;">Class 12</a></li>
              <li><a href="demo11.php" style=" color:#5299e6;">Class 11</a></li>
              <li><a href="demo10.php" style=" color:#5299e6;">Class 10</a></li>
              <li><a href="demo9.php" style=" color:#5299e6;">Class 9</a></li>
            </ul>
          </li>
		  <li class="drop-down"><a style=" color:#5299e6;" href="">KNOWLEDGE BITES</a>
            <ul>
              <li><a href="currentaff.php" style=" color:#5299e6;">Current Affairs</a></li>
              <li><a href="careercon.php" style=" color:#5299e6;"> Career Counselling</a></li>
              <li><a href="persanility.php" style=" color:#5299e6;">Personality Development</a></li>
              <li><a href="intervie.php" style=" color:#5299e6;">Interview Skills</a></li>
              <li><a href="powerpake.php" style=" color:#5299e6;">Power Packed Sessions</a></li>
              <li><a href="success.php" style=" color:#5299e6;">Success Mantra</a></li>
            </ul>
          </li>
		 

		     
          
         <li class="drop-down"><a style=" color:#5299e6;" href=""> STUDY MATERIAL</a>
            <ul>
              <li><a href="Pryear.php" style=" color:#5299e6;">Previous Year Paper</a></li>
              <li><a href="samplepaper.php" style=" color:#5299e6;"> Sample Papers</a></li>
              <li><a href="mock_paper.php" style=" color:#5299e6;">Social – Mock Papers
</a></li>
            <li><a href="course-details2.php" style=" color:#5299e6;">Social – NCERT Books

</a></li>   

<li><a href="course-details2.php" style=" color:#5299e6;">Toppers Answers Sheets


</a></li> 

<li><a href="course-details2.php" style=" color:#5299e6;">Important Questions


</a></li>



            </ul>
          </li>
         
           <li class="drop-down"><a style=" color:#5299e6;" href=""> SUBJECTS OFFERES</a>
            <ul>
              <li><a href="course-details.php" style=" color:#5299e6;">Commerce (XI – XII)</a></li>
              <li><a href="course-details1.php" style=" color:#5299e6;"> Humanities (XI – XII)</a></li>
              <li><a href="course-details2.php" style=" color:#5299e6;">Social – Science (IX – X)</a></li>
              
            </ul>
          </li>
          
        <li class="drop-down"><a style=" color:#5299e6;" href="courses.php"> GET ONLINE</a>
            <ul>
              <li><a href="http://ardventures.in/Coaching/coacing/sms/student/" style=" color:#5299e6;">For Student</a></li>
              <li><a href="http://ardventures.in/Coaching/coacing/sms/teacher/" style=" color:#5299e6;"> For Teacher</a></li>
              
            </ul>
          </li>

        </ul>
      </nav><!-- .nav-menu -->

      <a href="courses.php" class="get-started-btn" style="border:2px solid silver;background:#5299e6; color:white;" >
	  ENROLL NOW</a>

    </div>
  </header>
 <!-- End Header -->

  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <div style="background:#5299e6;" class="breadcrumbs" data-aos="fade-in">
      <div style="background:#5299e6;" class="container">
	  <br/>
<br/>
<br/>
        <h2>About Us</h2>
       
      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="row" style="text-align:justify;">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/123.jpg" class="img-fluid" alt=""><br/>
            <img src="assets/img/123.jpg" class="img-fluid" alt=""><br/>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h3>Welcome to the Web Platform of Narendra’s – Kirti Study Center,
			a digital way to explore the real you</h3>
            <p class="font-italic">
             The world is transforming and so as are we. In today’s world where various aspects of personality are
core for a defined and settled career then why learning for it should be time bounded. 
            </p>
            
            <p>
            We know that, community-learning occupies a special place in our hearts but then we also have to
understand that not every child is compatible enough with the same time defined by the authorities and
neither can he/she be present their whole-heartily always. Therefore, at our web-enabled platform we
will be providing Power-Packed Learning Sessions to the Enrolled Students, which they can access as
per their convenience. They can pause, rewind and work on concept as many times they want as
practice makes a man perfect.
            </p>
			
			 <p>
           Though virtual classes do not provide men-to-men session like traditional classroom approach, but yes
from now onwards not even we will be time-bounded. We will be open for your doubts, queries,
comments all 24x7, so as to facilitate uninterrupted studies. 
            </p>
			<p>Services Provided:</p>
			<ul>
              <li><i class="icofont-check-circled"></i> ❖ Digital Sessions
❖ Online-Tests
❖ Worksheets</li>
              <li><i class="icofont-check-circled"></i> ❖ Answer Submissions
❖ PDF Notes
❖ Doubt Solving Sessions</li>
              <li><i class="icofont-check-circled"></i> ❖ Live Classes
❖ Current Affair Submissions
</li>
            </ul>

          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
   <!-- End Testimonials Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" style=" color:#5299e6;">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact" style=" color:#5299e6;">
            <h6 style=" color:#5299e6;">Narendra Kriti Study Center</h6>
            <p style=" color:#5299e6;">
              2, Alka Puri, <br>
              Near Bersheba Church,<br>
              Udayan Marg, Ujjain – 456010 <br>
             Madhya Pradesh <br><br>
			  
			 



              <strong>Phone:</strong> +91 7987893235<br>
              <strong>Email:</strong> kirtistudycenter@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4 style=" color:#5299e6;">Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a style="    font-size: 16px; color:#5299e6;" href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a style="    font-size: 16px; color:#5299e6;" href="about.php">About us</a></li>
             
              <li><i class="bx bx-chevron-right"></i> <a style="font-size: 16px; color:#5299e6;" href="term.php">Our Administrative Team</a></li>
              
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4 style=" color:#5299e6;">Our Services</h4>
            <ul>
              <li><a href="course-details.php" style="font-size:16px; color:#5299e6;">Commerce (XI – XII)</a></li>
              <li><a href="course-details1.php" style="font-size:16px; color:#5299e6;"> Humanities (XI – XII)</a></li>
              <li><a href="course-details2.php" style="font-size:16px; color:#5299e6;">Social – Science (IX – X)</a></li>
              
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 style=" color:#5299e6;">Join Our Newsletter</h4>
            <p style=" color:#5299e6;"></p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" style="background:#5299e6;"value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>TSI</span></strong>
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/ -->
          
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" style="background:#5299e6;"class="twitter" ><i  class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"style="background:#5299e6;"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"style="background:#5299e6;"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="instagram"style="background:#5299e6;"><i class="bx bxl-youtube"></i></a>
     
       
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>